<template>
  <div id="app">
    
   <navbar-starwars> </navbar-starwars>
   <floatbutton @character-added="showCharacters"></floatbutton>
   <character-list :characters="characters"> </character-list>
  </div>
</template>

<script>
import navbarStarwars from "./components/navbarStarwars.vue";
import floatbutton from "./components/floatbutton.vue";
import characterList from "./components/characterList.vue";

export default {
  components: {
    navbarStarwars,
    floatbutton,
    characterList
  },
  data() {
    return {
      characters: []
    };
  },
  methods: {
    showCharacters(payload) {
      this.characters = payload;
    }
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;

  height: 100vh;

  position: relative;

  .collection {
    border: none;
  }
}
</style>
