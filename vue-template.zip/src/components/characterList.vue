<template>
  <ul class="collection">
    <li class="collection-item avatar" v-for="(characther, index) in characters" :key="index">
      <img src="https://cmkt-image-prd.global.ssl.fastly.net/0.1.0/ps/1412243/1160/772/m1/fpnw/wm0/lawyer-avatar-flat-icon-01-.jpg?1467280299&s=d7eb6ecfdcefaea78ca2cef1143c9dde" alt="" class="circle">
      <span class="title">{{characther.name}}</span>
   </li>
  </ul>
</template>

<script>
export default {
  props: {
    characters: Array
  }
};
</script>
  
<style>
</style>
